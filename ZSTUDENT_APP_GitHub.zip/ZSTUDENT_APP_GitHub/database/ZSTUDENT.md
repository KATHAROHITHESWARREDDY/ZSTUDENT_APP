# ZSTUDENT

Create using SE11 → Database Table.

| Field | Type | Key | Description |
|---|---|---|---|
| MANDT | MANDT | Yes | Client |
| STUDENT_ID | CHAR10 | Yes | Student identifier |
| FIRST_NAME | CHAR30 | No | First name |
| LAST_NAME | CHAR30 | No | Last name |
| DOB | DATS | No | Date of birth |
| GENDER | CHAR1 | No | Gender |
| EMAIL | CHAR50 | No | Email address |
| PHONE | CHAR15 | No | Phone number |
| COURSE_ID | CHAR10 | No | Course identifier |
| ADMISSION_DATE | DATS | No | Admission date |
| STATUS | CHAR10 | No | Student status |

Activate the table after maintaining Technical Settings.
