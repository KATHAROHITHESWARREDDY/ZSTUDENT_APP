# ZCOURSE

| Field | Type | Key | Description |
|---|---|---|---|
| MANDT | MANDT | Yes | Client |
| COURSE_ID | CHAR10 | Yes | Course identifier |
| COURSE_NAME | CHAR50 | No | Course name |
| DURATION | INT4 | No | Duration in years |
| MAX_MARKS | INT4 | No | Maximum marks |

Activate in SE11.
