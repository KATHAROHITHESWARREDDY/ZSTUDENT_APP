# ZENROLL

| Field | Type | Key | Description |
|---|---|---|---|
| MANDT | MANDT | Yes | Client |
| STUDENT_ID | CHAR10 | Yes | Student identifier |
| COURSE_ID | CHAR10 | Yes | Course identifier |
| ENROLL_DATE | DATS | No | Enrollment date |
| STATUS | CHAR10 | No | Enrollment status |

The composite key `(STUDENT_ID, COURSE_ID)` prevents duplicate enrollment for the same student and course.
