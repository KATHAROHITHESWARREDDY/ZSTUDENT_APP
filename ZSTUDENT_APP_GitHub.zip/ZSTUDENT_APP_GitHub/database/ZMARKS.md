# ZMARKS

| Field | Type | Key | Description |
|---|---|---|---|
| MANDT | MANDT | Yes | Client |
| STUDENT_ID | CHAR10 | Yes | Student identifier |
| COURSE_ID | CHAR10 | Yes | Course identifier |
| SUBJECT | CHAR50 | Yes | Subject |
| MARKS | DEC5_2 | No | Obtained marks |
| MAX_MARKS | DEC5_2 | No | Maximum marks |

The application validates that marks are not negative and do not exceed maximum marks.
