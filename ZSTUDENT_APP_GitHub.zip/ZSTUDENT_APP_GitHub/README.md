# ZSTUDENT_APP — SAP ABAP Student Management System

A SAP ABAP Module Pool application for managing students, courses, enrollment, marks, and results.

## Project requirements

Based on the supplied Project 3 specification:

- Module Pool program: `ZSTUDENT_APP`
- Transaction: `ZSTUDENT`
- Main screen: Student Management System
- Database tables:
  - `ZSTUDENT`
  - `ZCOURSE`
  - `ZENROLL`
  - `ZMARKS`
- Operations:
  - CREATE
  - CHANGE
  - DISPLAY
  - DELETE
  - BACK
  - EXIT
- Validations:
  - Student ID cannot be blank
  - Email must be valid
  - Course must exist
  - Student cannot be enrolled twice
  - Marks cannot exceed maximum marks
  - Marks cannot be negative
- Final report:
  - Student
  - Course
  - Subject
  - Marks
  - Percentage
  - Grade
  - Result

## Repository contents

```text
ZSTUDENT_APP/
├── README.md
├── LICENSE
├── .gitignore
├── src/
│   ├── zstudent_app.abap
│   └── zstudent_report.abap
├── database/
│   ├── ZSTUDENT.md
│   ├── ZCOURSE.md
│   ├── ZENROLL.md
│   └── ZMARKS.md
├── screens/
│   ├── screen_0100_flow_logic.abap
│   └── screen_0100_layout.md
├── docs/
│   └── SAP_SETUP.md
└── test-data/
    └── sample_data.md
```

## Important SAP note

This repository contains the ABAP source and the exact SAP GUI/Dynpro setup instructions. SAP Module Pool objects such as Screen Painter layouts and GUI statuses are created in the SAP system using SE80/SE51 and are not represented as ordinary `.abap` source files.

## Installation

1. Create the four tables from `database/`.
2. Create Module Pool program `ZSTUDENT_APP`.
3. Create screen `0100`.
4. Create the screen fields described in `screens/screen_0100_layout.md`.
5. Add the PBO/PAI flow logic from `screens/screen_0100_flow_logic.abap`.
6. Create GUI status `MAIN`.
7. Paste `src/zstudent_app.abap` into the program.
8. Create transaction `ZSTUDENT` pointing to program `ZSTUDENT_APP`, screen `0100`.
9. Activate all objects.
10. Insert sample courses from `test-data/sample_data.md`.
11. Test CREATE, DISPLAY, CHANGE and DELETE.
12. Test the final report program in `src/zstudent_report.abap`.

## Suggested GitHub repository name

`SAP-ABAP-Student-Management-System`

## Suggested description

> SAP ABAP Module Pool Student Management System with CRUD operations, course validation, enrollment validation, marks validation and final result reporting.
