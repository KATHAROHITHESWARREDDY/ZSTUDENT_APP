*&---------------------------------------------------------------------*
*& Module Pool      ZSTUDENT_APP
*&---------------------------------------------------------------------*
*& Student Management System
*& Screen: 0100
*& GUI Status: MAIN
*&---------------------------------------------------------------------*

PROGRAM zstudent_app.

TABLES: zstudent, zcourse, zenroll, zmarks.

DATA:
  gv_student_id     TYPE zstudent-student_id,
  gv_first_name     TYPE zstudent-first_name,
  gv_last_name      TYPE zstudent-last_name,
  gv_dob            TYPE zstudent-dob,
  gv_gender         TYPE zstudent-gender,
  gv_email          TYPE zstudent-email,
  gv_phone          TYPE zstudent-phone,
  gv_course_id      TYPE zstudent-course_id,
  gv_admission_date TYPE zstudent-admission_date,
  gv_status         TYPE zstudent-status.

MODULE status_0100 OUTPUT.
  SET PF-STATUS 'MAIN'.
  SET TITLEBAR 'STUDENT'.
ENDMODULE.

MODULE user_command_0100 INPUT.
  CASE sy-ucomm.
    WHEN 'CREATE'.
      PERFORM create_student.

    WHEN 'CHANGE'.
      PERFORM change_student.

    WHEN 'DISPLAY'.
      PERFORM display_student.

    WHEN 'DELETE'.
      PERFORM delete_student.

    WHEN 'BACK'.
      LEAVE TO SCREEN 0.

    WHEN 'EXIT'.
      LEAVE PROGRAM.

    WHEN OTHERS.
      MESSAGE 'Unknown command' TYPE 'I'.
  ENDCASE.
ENDMODULE.

FORM validate_email CHANGING cv_valid TYPE abap_bool.
  DATA lv_at TYPE i.
  DATA lv_dot TYPE i.

  cv_valid = abap_false.

  IF gv_email IS INITIAL.
    RETURN.
  ENDIF.

  lv_at = find( val = gv_email sub = '@' ).
  lv_dot = find( val = gv_email sub = '.' occ = -1 ).

  IF lv_at > 0 AND lv_dot > lv_at + 1 AND lv_dot < strlen( gv_email ) - 1.
    cv_valid = abap_true.
  ENDIF.
ENDFORM.

FORM validate_course CHANGING cv_valid TYPE abap_bool.
  DATA lv_course_id TYPE zcourse-course_id.

  cv_valid = abap_false.

  IF gv_course_id IS INITIAL.
    RETURN.
  ENDIF.

  SELECT SINGLE course_id
    FROM zcourse
    WHERE course_id = @gv_course_id
    INTO @lv_course_id.

  IF sy-subrc = 0.
    cv_valid = abap_true.
  ENDIF.
ENDFORM.

FORM create_student.
  DATA ls_student TYPE zstudent.
  DATA lv_valid   TYPE abap_bool.

  IF gv_student_id IS INITIAL.
    MESSAGE 'Student ID cannot be blank' TYPE 'E'.
  ENDIF.

  PERFORM validate_email CHANGING lv_valid.
  IF lv_valid = abap_false.
    MESSAGE 'Enter a valid email address' TYPE 'E'.
  ENDIF.

  PERFORM validate_course CHANGING lv_valid.
  IF lv_valid = abap_false.
    MESSAGE 'Course does not exist' TYPE 'E'.
  ENDIF.

  SELECT SINGLE student_id
    FROM zstudent
    WHERE student_id = @gv_student_id
    INTO @DATA(lv_existing_id).

  IF sy-subrc = 0.
    MESSAGE 'Student already exists' TYPE 'E'.
  ENDIF.

  CLEAR ls_student.

  ls_student-student_id     = gv_student_id.
  ls_student-first_name     = gv_first_name.
  ls_student-last_name      = gv_last_name.
  ls_student-dob            = gv_dob.
  ls_student-gender         = gv_gender.
  ls_student-email          = gv_email.
  ls_student-phone          = gv_phone.
  ls_student-course_id      = gv_course_id.
  ls_student-admission_date = gv_admission_date.
  ls_student-status         = gv_status.

  INSERT zstudent FROM @ls_student.

  IF sy-subrc = 0.
    COMMIT WORK AND WAIT.
    MESSAGE 'Student created successfully' TYPE 'S'.
  ELSE.
    ROLLBACK WORK.
    MESSAGE 'Error while creating student' TYPE 'E'.
  ENDIF.
ENDFORM.

FORM display_student.
  DATA ls_student TYPE zstudent.

  IF gv_student_id IS INITIAL.
    MESSAGE 'Enter Student ID' TYPE 'E'.
  ENDIF.

  SELECT SINGLE *
    FROM zstudent
    WHERE student_id = @gv_student_id
    INTO @ls_student.

  IF sy-subrc <> 0.
    MESSAGE 'Student not found' TYPE 'E'.
  ENDIF.

  gv_first_name     = ls_student-first_name.
  gv_last_name      = ls_student-last_name.
  gv_dob            = ls_student-dob.
  gv_gender         = ls_student-gender.
  gv_email          = ls_student-email.
  gv_phone          = ls_student-phone.
  gv_course_id      = ls_student-course_id.
  gv_admission_date = ls_student-admission_date.
  gv_status         = ls_student-status.

  MESSAGE 'Student details displayed' TYPE 'S'.
ENDFORM.

FORM change_student.
  DATA lv_valid TYPE abap_bool.

  IF gv_student_id IS INITIAL.
    MESSAGE 'Student ID cannot be blank' TYPE 'E'.
  ENDIF.

  PERFORM validate_email CHANGING lv_valid.
  IF lv_valid = abap_false.
    MESSAGE 'Enter a valid email address' TYPE 'E'.
  ENDIF.

  PERFORM validate_course CHANGING lv_valid.
  IF lv_valid = abap_false.
    MESSAGE 'Course does not exist' TYPE 'E'.
  ENDIF.

  UPDATE zstudent
     SET first_name     = @gv_first_name,
         last_name      = @gv_last_name,
         dob            = @gv_dob,
         gender         = @gv_gender,
         email          = @gv_email,
         phone          = @gv_phone,
         course_id      = @gv_course_id,
         admission_date = @gv_admission_date,
         status         = @gv_status
   WHERE student_id     = @gv_student_id.

  IF sy-subrc = 0.
    COMMIT WORK AND WAIT.
    MESSAGE 'Student updated successfully' TYPE 'S'.
  ELSE.
    ROLLBACK WORK.
    MESSAGE 'Student not found or update failed' TYPE 'E'.
  ENDIF.
ENDFORM.

FORM delete_student.
  IF gv_student_id IS INITIAL.
    MESSAGE 'Enter Student ID' TYPE 'E'.
  ENDIF.

  DELETE FROM zstudent
    WHERE student_id = @gv_student_id.

  IF sy-subrc = 0.
    COMMIT WORK AND WAIT.
    MESSAGE 'Student deleted successfully' TYPE 'S'.
  ELSE.
    ROLLBACK WORK.
    MESSAGE 'Student not found' TYPE 'E'.
  ENDIF.
ENDFORM.
