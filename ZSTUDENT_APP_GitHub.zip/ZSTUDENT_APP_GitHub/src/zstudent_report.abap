*&---------------------------------------------------------------------*
*& Report ZSTUDENT_REPORT
*&---------------------------------------------------------------------*
*& Final Student Result Report
*&---------------------------------------------------------------------*

REPORT zstudent_report.

TABLES: zstudent, zcourse, zmarks.

TYPES: BEGIN OF ty_result,
         student_id TYPE zstudent-student_id,
         first_name TYPE zstudent-first_name,
         last_name  TYPE zstudent-last_name,
         course_id  TYPE zstudent-course_id,
         course_name TYPE zcourse-course_name,
         subject    TYPE zmarks-subject,
         marks      TYPE zmarks-marks,
         max_marks  TYPE zmarks-max_marks,
         percentage TYPE p LENGTH 7 DECIMALS 2,
         grade      TYPE char2,
         result     TYPE char10,
       END OF ty_result.

DATA gt_result TYPE STANDARD TABLE OF ty_result WITH EMPTY KEY.

SELECT-OPTIONS:
  s_stuid FOR zstudent-student_id,
  s_cid   FOR zstudent-course_id.

START-OF-SELECTION.

  SELECT
    s~student_id,
    s~first_name,
    s~last_name,
    s~course_id,
    c~course_name,
    m~subject,
    m~marks,
    m~max_marks
    FROM zstudent AS s
    INNER JOIN zcourse AS c
      ON c~course_id = s~course_id
    INNER JOIN zmarks AS m
      ON m~student_id = s~student_id
     AND m~course_id  = s~course_id
    WHERE s~student_id IN @s_stuid
      AND s~course_id  IN @s_cid
    INTO CORRESPONDING FIELDS OF TABLE @gt_result.

  LOOP AT gt_result ASSIGNING FIELD-SYMBOL(<ls_result>).

    IF <ls_result>-max_marks > 0.
      <ls_result>-percentage =
        ( <ls_result>-marks * 100 ) / <ls_result>-max_marks.
    ELSE.
      <ls_result>-percentage = 0.
    ENDIF.

    IF <ls_result>-marks < 0
       OR <ls_result>-marks > <ls_result>-max_marks.
      <ls_result>-result = 'INVALID'.
      <ls_result>-grade  = '-'.
    ELSEIF <ls_result>-percentage >= 90.
      <ls_result>-grade  = 'A+'.
      <ls_result>-result = 'PASS'.
    ELSEIF <ls_result>-percentage >= 80.
      <ls_result>-grade  = 'A'.
      <ls_result>-result = 'PASS'.
    ELSEIF <ls_result>-percentage >= 70.
      <ls_result>-grade  = 'B'.
      <ls_result>-result = 'PASS'.
    ELSEIF <ls_result>-percentage >= 60.
      <ls_result>-grade  = 'C'.
      <ls_result>-result = 'PASS'.
    ELSEIF <ls_result>-percentage >= 50.
      <ls_result>-grade  = 'D'.
      <ls_result>-result = 'PASS'.
    ELSE.
      <ls_result>-grade  = 'F'.
      <ls_result>-result = 'FAIL'.
    ENDIF.

  ENDLOOP.

  IF gt_result IS INITIAL.
    MESSAGE 'No result data found' TYPE 'I'.
    RETURN.
  ENDIF.

  TRY.
      cl_salv_table=>factory(
        IMPORTING r_salv_table = DATA(lo_alv)
        CHANGING  t_table      = gt_result ).

      lo_alv->get_functions( )->set_all( abap_true ).
      lo_alv->get_columns( )->set_optimize( abap_true ).
      lo_alv->display( ).

    CATCH cx_salv_msg INTO DATA(lx_salv).
      MESSAGE lx_salv->get_text( ) TYPE 'E'.
  ENDTRY.
