# SAP Setup Guide

## 1. Create database tables

Use transaction `SE11`.

Create and activate:

1. `ZSTUDENT`
2. `ZCOURSE`
3. `ZENROLL`
4. `ZMARKS`

Use the field definitions in `/database`.

## 2. Create Module Pool

Use `SE80`.

- Object type: ABAP Program
- Program: `ZSTUDENT_APP`
- Program type: Module Pool

Paste the contents of:

`src/zstudent_app.abap`

## 3. Create screen

Create screen `0100`.

Screen type:

`Normal`

Create the fields listed in:

`screens/screen_0100_layout.md`

## 4. Screen flow logic

Open Screen 0100 → Flow Logic and use:

```abap
PROCESS BEFORE OUTPUT.
  MODULE STATUS_0100.

PROCESS AFTER INPUT.
  MODULE USER_COMMAND_0100.
```

## 5. GUI Status

Create GUI status:

`MAIN`

Add the required function codes:

- CREATE
- CHANGE
- DISPLAY
- DELETE
- BACK
- EXIT

Create title:

`STUDENT`

## 6. Transaction

Use `SE93`.

Transaction:

`ZSTUDENT`

Select:

`Program and screen (dialog transaction)`

Program:

`ZSTUDENT_APP`

Screen:

`0100`

Save and activate.

## 7. Final report

Create executable program:

`ZSTUDENT_REPORT`

Paste:

`src/zstudent_report.abap`

The report uses SALV and reads student/course/marks data.

## 8. Test order

Recommended order:

1. Create a course.
2. Create a student.
3. Display the student.
4. Change the student.
5. Add marks.
6. Run `ZSTUDENT_REPORT`.
7. Test invalid email.
8. Test nonexistent course.
9. Test blank Student ID.
10. Test marks outside the valid range.
