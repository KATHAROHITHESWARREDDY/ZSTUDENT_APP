# Sample Test Data

## ZCOURSE

| COURSE_ID | COURSE_NAME | DURATION | MAX_MARKS |
|---|---|---:|---:|
| CSE101 | Computer Science | 4 | 100 |
| ECE101 | Electronics | 4 | 100 |
| AIML101 | Artificial Intelligence | 4 | 100 |

## ZSTUDENT

| STUDENT_ID | FIRST_NAME | LAST_NAME | GENDER | EMAIL | PHONE | COURSE_ID | STATUS |
|---|---|---|---|---|---|---|---|
| S001 | Rohit | Reddy | M | rohit@example.com | 9876543210 | CSE101 | ACTIVE |
| S002 | Student | Two | F | student2@example.com | 9876543211 | AIML101 | ACTIVE |

## ZENROLL

| STUDENT_ID | COURSE_ID | ENROLL_DATE | STATUS |
|---|---|---|---|
| S001 | CSE101 | 20261008 | ACTIVE |
| S002 | AIML101 | 20261008 | ACTIVE |

## ZMARKS

| STUDENT_ID | COURSE_ID | SUBJECT | MARKS | MAX_MARKS |
|---|---|---|---:|---:|
| S001 | CSE101 | Java | 85 | 100 |
| S001 | CSE101 | DBMS | 78 | 100 |
| S001 | CSE101 | Networks | 92 | 100 |
| S002 | AIML101 | Python | 88 | 100 |

## Validation tests

### Test 1 — Blank Student ID
Leave Student ID empty and press CREATE.

Expected:
`Student ID cannot be blank`

### Test 2 — Invalid email
Use:
`rohit@`

Expected:
`Enter a valid email address`

### Test 3 — Invalid course
Use a course ID that does not exist.

Expected:
`Course does not exist`

### Test 4 — Duplicate student
Create `S001` again.

Expected:
`Student already exists`

### Test 5 — Marks greater than maximum
Do not insert a mark greater than `MAX_MARKS`.

### Test 6 — Negative marks
Do not insert a negative mark.
