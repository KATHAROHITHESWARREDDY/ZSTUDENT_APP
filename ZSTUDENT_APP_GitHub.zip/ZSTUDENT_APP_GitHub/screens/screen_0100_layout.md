# Screen 0100 — Layout

Create a normal screen in SE80/SE51.

## Title

`STUDENT MANAGEMENT SYSTEM`

## Input fields

| Screen field | Program field |
|---|---|
| Student ID | `GV_STUDENT_ID` |
| First Name | `GV_FIRST_NAME` |
| Last Name | `GV_LAST_NAME` |
| DOB | `GV_DOB` |
| Gender | `GV_GENDER` |
| Email | `GV_EMAIL` |
| Phone | `GV_PHONE` |
| Course | `GV_COURSE_ID` |
| Admission Date | `GV_ADMISSION_DATE` |
| Status | `GV_STATUS` |

## Pushbuttons

| Text | Function Code |
|---|---|
| CREATE | CREATE |
| CHANGE | CHANGE |
| DISPLAY | DISPLAY |
| DELETE | DELETE |
| BACK | BACK |
| EXIT | EXIT |

## GUI status

Create GUI status `MAIN` and include the function codes above as needed.
